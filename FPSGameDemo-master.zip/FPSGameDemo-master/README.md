# FPSGameDemo

shooting target resource from https://sketchfab.com/3d-models/target-diana-rafael-lopera-3474367be47942f697389ecc59577c68

release build in [Release directory](Release/)