// Copyright Epic Games, Inc. All Rights Reserved.

#include "FPSGameDemoGameMode.h"
#include "FPSGameDemoHUD.h"
#include "FPSGameDemoCharacter.h"
#include "FPSGameDemoPlayerState.h"
#include "UObject/ConstructorHelpers.h"

AFPSGameDemoGameMode::AFPSGameDemoGameMode()
	: Super()
{
	// set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnClassFinder(TEXT("/Game/FirstPersonCPP/Blueprints/FirstPersonCharacter"));
	DefaultPawnClass = PlayerPawnClassFinder.Class;

	// use our custom HUD class
	HUDClass = AFPSGameDemoHUD::StaticClass();

	// use custom player state class for hit count storage
	PlayerStateClass = AFPSGameDemoPlayerState::StaticClass();
}
