// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "FPSGameDemoGameMode.generated.h"

UCLASS(minimalapi)
class AFPSGameDemoGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AFPSGameDemoGameMode();
};



