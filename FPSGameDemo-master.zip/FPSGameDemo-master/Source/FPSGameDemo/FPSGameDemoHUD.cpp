// Copyright Epic Games, Inc. All Rights Reserved.

#include "FPSGameDemoHUD.h"
#include "Engine/Canvas.h"
#include "Engine/Texture2D.h"
#include "CanvasItem.h"
#include "FPSGameDemoPlayerState.h"
#include "GameFramework/GameState.h"
#include "UObject/ConstructorHelpers.h"

AFPSGameDemoHUD::AFPSGameDemoHUD()
{
	// Set the crosshair texture
	static ConstructorHelpers::FObjectFinder<UTexture2D> CrosshairTexObj(
		TEXT("/Game/FirstPerson/Textures/FirstPersonCrosshair"));
	CrosshairTex = CrosshairTexObj.Object;
}


void AFPSGameDemoHUD::DrawHUD()
{
	Super::DrawHUD();

	// Draw very simple crosshair

	// find center of the Canvas
	const FVector2D Center(Canvas->ClipX * 0.5f, Canvas->ClipY * 0.5f);

	// offset by half the texture's dimensions so that the center of the texture aligns with the center of the Canvas
	const FVector2D CrosshairDrawPosition((Center.X),
	                                      (Center.Y + 20.0f));

	// draw the crosshair
	FCanvasTileItem TileItem(CrosshairDrawPosition, CrosshairTex->Resource, FLinearColor::White);
	TileItem.BlendMode = SE_BLEND_Translucent;
	Canvas->DrawItem(TileItem);

	// Draw score board
	DrawText(TEXT("FPSGameDemo Score Board:"), FLinearColor::White, 20.0f, 20.0f,
	         GEngine->GetLargeFont(), 1, 1);
	AGameStateBase* const GameState = PlayerOwner->GetWorld() != nullptr
		                                  ? PlayerOwner->GetWorld()->GetGameState<AGameStateBase>()
		                                  : nullptr;
	if (!GameState)
	{
		UE_LOG(LogTemp, Warning, TEXT("GameState is nullptr"));
		return;
	}
	for (int PlayerIndex = 0; PlayerIndex < GameState->PlayerArray.Num(); PlayerIndex++)
	{
		const AFPSGameDemoPlayerState* const PlayerState = Cast<AFPSGameDemoPlayerState>(
			GameState->PlayerArray[PlayerIndex]);
		const int HitCount = PlayerState->GetHitCount();
		DrawText(TEXT("Player ") + PlayerState->GetPlayerName() + TEXT(": ") +
		         FString::FromInt(HitCount), FLinearColor::White, 20.0f, 20.0f + 20.0f * (PlayerIndex + 1),
		         GEngine->GetLargeFont(), 1, 1);
	}
}
