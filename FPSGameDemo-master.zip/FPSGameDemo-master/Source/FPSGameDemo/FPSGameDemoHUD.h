// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once 

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "FPSGameDemoHUD.generated.h"

UCLASS()
class AFPSGameDemoHUD : public AHUD
{
	GENERATED_BODY()

public:
	AFPSGameDemoHUD();

	/** Primary draw call for the HUD */
	virtual void DrawHUD() override;

private:
	/** Crosshair asset pointer */
	class UTexture2D* CrosshairTex;

};

