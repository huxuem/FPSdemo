﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "FPSGameDemoPlayerState.h"

void AFPSGameDemoPlayerState::SetHitCount(const int NewValue)
{
	HitCount = NewValue;
}

void AFPSGameDemoPlayerState::AddHitCount(const int ToAdd)
{
	HitCount += ToAdd;
}

int AFPSGameDemoPlayerState::GetHitCount() const
{
	return HitCount;
}
