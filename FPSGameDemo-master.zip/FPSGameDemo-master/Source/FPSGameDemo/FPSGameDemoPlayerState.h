﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerState.h"
#include "FPSGameDemoPlayerState.generated.h"

/**
 * 
 */
UCLASS()
class FPSGAMEDEMO_API AFPSGameDemoPlayerState : public APlayerState
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintCallable)
	void SetHitCount(const int NewValue);

	UFUNCTION(BlueprintCallable)
	void AddHitCount(const int ToAdd);

	UFUNCTION(BlueprintCallable)
	int GetHitCount() const;
	
protected:
	int HitCount = 0;
};
